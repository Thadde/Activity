package FirstTesting;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class similaires {

	@Test
	void test() {
		TabAlgos test = new TabAlgos();
		boolean output = TabAlgos.similaires(123, 234);
		assertEquals(false, output);
	}

}
