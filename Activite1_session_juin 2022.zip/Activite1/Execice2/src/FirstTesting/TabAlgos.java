package FirstTesting;

public class TabAlgos {

	/** @return valeur la plus grande d'un tableau. */
	public static int plusGrand(final int[] tab) {
		return 0;
		// TODO
	}

	/**
	 * @return moyenne des valeurs du tableau.
	 * @throw IllegalArgumentException si tab et null ou vide.
	 **/
	public static double moyenne(final int[] tab) {
		return 0;
		// TODO
	}

	/**
	 * Compare le contenu de 2 tableaux en tenant compte de l'ordre.
	 * 
	 * @return true si les 2 tableaux contiennent les m�mes �l�ments avec les m�mes
	 *         nombres d'occurences (avec les elements dans le meme ordre).
	 **/
	public static boolean egaux(final int i, final int j) {
		return false;
		// TODO
	}

	/**
	 * Compare le contenu de 2 tableaux sans tenir compte de l'ordre.
	 * 
	 * @return true si les 2 tableaux contiennent les m�mes �l�ments avec les m�mes
	 *         nombres d'occurrence (pas forc�ment dans le meme ordre).
	 **/
	public static boolean similaires(final int i, final int j) {
		return false;
		// TODO
	}

	public int plusGrand(int i, int j) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int moyenne(int i, int j) {
		// TODO Auto-generated method stub
		return 0;
	}

}
