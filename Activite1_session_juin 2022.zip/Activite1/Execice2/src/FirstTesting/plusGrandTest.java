package FirstTesting;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class plusGrandTest {

	@Test
	public void test() {
		TabAlgos test = new TabAlgos();
		int output = test.plusGrand(5, 7);
		assertEquals(7, output);
	}

}
