package FirstTesting;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class moyenne {

	@Test
	void test() {
		TabAlgos test = new TabAlgos();
		int output = test.moyenne(7, 15);
		assertEquals(11, output);

	}
}
