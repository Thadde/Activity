package FirstTesting;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class egaux {

	@Test
	void test() {
		TabAlgos test = new TabAlgos();
		boolean output = test.egaux(7, 15);
		assertEquals(false, output);

	}

}
