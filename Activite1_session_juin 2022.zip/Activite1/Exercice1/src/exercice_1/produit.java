package exercice_1;

public class produit {

}
