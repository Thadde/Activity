package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Test.Jtest;

class JtestTest {

	@Test
	void testMultiplication() {
		assertEquals(16,Jtest.multiplication(8,2));
	}

}
