package Test;

public class Jtest {
	
	public static int multiplication(int a,int b) {
		return a*b;
	}

}
